LD405 pulse driver - design review package
=========================================

A TTL-gated constant-current driver for a 405 nm laser diode (BDR-209, ~0.9 W),
used as the second, ionising step of two-photon REMPI during ablation loading
of an ion trap. Board revision 1.0; package built 2026-10-30 from commit ed5fcb5
of ParsaIQT/Fiber-solarisation (folder laser-pulse-driver/).

Status: pre-production. Nothing has been built yet; the boards are to be
assembled by JLCPCB.

Start with LD405_design_review.pdf. Section 1 lists the questions we would most
like answered; section 10 lists what has and has not been verified.

To open the design: kicad/ld405-driver.kicad_pro in KiCad 9 (the custom
footprints and 3D models are in kicad/lib/ and are found through the project's
fp-lib-table; everything else is KiCad's standard library).

To re-run the simulations: install ngspice and numpy, then in simulation/
run ./get_models.sh (downloads the TI and Infineon models) and
python3 run_sims.py.

Folders:
  00_README.txt              what this package is and where to start
  LD405_design_review.pdf    the review document: start here
  schematic/                 ld405-driver_schematic.pdf (A0, vector)
  pcb/                       layer plots (F.Cu, In1.Cu, In2.Cu, B.Cu, silkscreen, fab), assembly drawing, 3D renders
  manufacturing/             the files uploaded to JLCPCB: Gerber/drill zip, BOM, CPL (with rotation offsets), full BOM
  kicad/                     KiCad 9 project (schematic, PCB, project file, custom footprints and 3D models)
  checks/                    KiCad ERC and DRC reports from this build
  simulation/                ngspice testbench and corner script, results of this build, simulated pulse plot; vendor models are fetched by get_models.sh
  enclosure/                 OpenSCAD source, STL files (print orientation), previews
  review_renders/            the review renders: footprints vs datasheets, polarity and JLC marker maps, copper close-ups, panel cross-sections, diode cable (index in README.md)
  docs/                      design notes, ordering and assembly guide (README), ARTIQ example
  source/                    the generator scripts (design.py holds every part, value, LCSC number and connection)
